package com.example.demo;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

// Annotation
@RestController

public class EmployeeController {
    @Autowired private EmployeeService employeeService;

    @PostMapping("/employee")
    public Employee saveDepartment(@RequestBody Employee employee) { return employeeService.saveEmployee(employee);

    @GetMapping("/employees")
    public List<Employee> fetchDepartmentList() { return  employeeService.fetchEmployeeList();}

    @PutMapping("/employees/{id}")
    public  Employee updateDepartment(@RequestBody Employee employee, @PathVaiable("id") Long employeeId)
        {
            return employeeService.updateEmployee(employee, employeeId);
        }

        // Delete operation
        @DeleteMapping("/employees/{id}")
        public String deleteDepartmentById(@PathVariable("id") Long departmentId)
        {
            employeeService.deleteEmployeeId(departmentId);
            return "Deleted Successfully";
        }
}