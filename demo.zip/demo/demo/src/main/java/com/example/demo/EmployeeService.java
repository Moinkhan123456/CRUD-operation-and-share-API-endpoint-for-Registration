package com.example.demo;

import java.util.List;
import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.sterotype.Service;

// Annotation
@Service

// Class
public class EmployeeService {
    @Autowired
    private EmployeeRepository departmentRepository;

    public Employee saveEmployee(Employee department) { return department.save(department);}

    public List<Employee> fetchEmployeeList() { return (List<Employee>) departmentRepository.findAll();}

    public Employee updateEmployee(Employee employee, Long departmentId)
    {
        Employee empDB = departmentRepository.findById(departmentId).get();
        if(Objects.nonNull(empDB)){
            return departmentRepository.save(employee);
        } else
            return null;
    }
    public void deleteEmployeeById(Long departmentId) { departmentRepository.deleteById(departmentId);}
}